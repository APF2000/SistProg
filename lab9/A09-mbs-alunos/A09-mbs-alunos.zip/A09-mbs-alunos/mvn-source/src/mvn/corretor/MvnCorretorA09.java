package mvn.corretor;

import mvn.Bits8;
import mvn.MvnControle;
import mvn.controle.MVNException;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * Created by deborasetton on 15/03/16.
 */
public class MvnCorretorA09 {

    /**
     * Número de iterações do código para o qual pode-se considerar que o
     * programa entrou em loop infinito e não vai parar.
     */
    public static int NUM_LOOP_INFINITO = 20000;
    private int passCount = 0;
    private int failCount = 0;

    private MvnControle mvn;
    private StringBuilder initOutput;

    public static void main(String[] args) throws MVNException {
        MvnCorretorA09 corretor = new MvnCorretorA09();
        corretor.corrigir();
    }

    public void corrigir() throws MVNException {

        passCount = 0;
        failCount = 0;

        this.mvn = new MvnControle();

        this.initOutput = new StringBuilder();
        mvn.initialize(initOutput);

        System.out.println(initOutput.toString());

        File f = getMainProgramFile();

        int[] codeCases = { 0, 1, 2, 3, 4 };
        String[] testCases = { "OK", "ER:JOB", "ER:CMD", "ER:ARG", "ER:END" };

        for (int i = 0; i < testCases.length; i++) {
            // Limpa a memória antes de começarmos.
            mvn.getMemoria().clear();

            // Adiciona o dispositivo (arquivo de saída).

            if (i > 0) {
                mvn.removeDispositivo(3, 0xFF);
            }

            mvn.addDispositivo(3, 0xFF, new String[]{ "log-" + codeCases[i] + ".txt", "e" });

            mvn.loadFileToMemory(f.getAbsolutePath());

            Bits8 code = new Bits8(codeCases[i]);
            mvn.getMemoria().write(code, 3);

            runMvn();

            // Verifica se o arquivo de log existe:
            File logFile = getLogFile(codeCases[i]);
            try {
                List<String> lines = Files.readAllLines(Paths.get(logFile.getAbsolutePath()), StandardCharsets.US_ASCII);

                if (lines.size() == 0) {
                    System.out.printf("[Fail] Teste do código %d incorreto: não escreveu no arquivo de log\n", codeCases[i]);
                    failCount++;
                }
                else if (lines.get(0).equals(testCases[i])) {
                    System.out.printf("[Ok] Mensagem de erro para o código %d correta.\n", codeCases[i]);
                    passCount++;
                }
                else {
                    System.out.printf("[Fail] Mensagem de erro para o código %d incorreta. Esperado: %s. Recebido: %s\n",
                            codeCases[i], testCases[i], lines.get(0));
                    failCount++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        double nota = ((float) (passCount)) / (passCount + failCount);
        System.out.printf("\nNota: %.3f\n", nota);

    }

    public void runMvn() throws MVNException {
        //------ Executa a MVN
        // --------------------------------------------------------------------------
        this.mvn.start(0x0, true);
        boolean continueRunning = true;
        int iterations = 0;
        try {
            do {
                continueRunning = mvn.resume();
                System.out.println(this.mvn.getCpu().obterRegs().toString());

                //Loop infinito?
                iterations++;
                if (iterations > NUM_LOOP_INFINITO) {
                    continueRunning = false;
                }

            } while (continueRunning);
        } catch (Exception ex) { //erro na execução
            String errorString = "Falha na execução. " + ex;
            System.out.println(errorString);
        }

        //Erro: loop infinito
        if (iterations > NUM_LOOP_INFINITO) {
            String errorString = "Execução não parou após " + iterations + " iterações: loop infinito?";
            System.out.println(errorString);
        }
        // --------------------------------------------------------------------------

    }


    public File getMainProgramFile() throws MVNException {
        StringBuilder b = new StringBuilder();
        b.append(".." + File.separator);
        b.append("os_0EE_00.mvn");

        String filePath = b.toString();
        File f = new File(filePath);

        if (f == null) {
            throw new MVNException("Arquivo não encontrado: " + f.getAbsolutePath());
        }

        return f;
    }

    public File getLogFile(int code) throws MVNException {
        StringBuilder b = new StringBuilder();
        b.append("log-" + code + ".txt");

        String filePath = b.toString();
        File f = new File(filePath);

        if (f == null) {
            throw new MVNException("Arquivo não encontrado: " + f.getAbsolutePath());
        }

        return f;
    }


}
