cat inicio
cd misterio
ls
cat cena-do-crime
ls
cd ..
ls
cd misterio/
ls
cd entrevistas/
ls
cat entrevista-221039
ls
cd ..
ls
cat automoveis
find automoveis -name "ZMZPA76"
find automoveis -name "*ZMZPA76"
find automoveis -name "*ZMZPA76*"
grep "ZMZPA76" *
cd ..
ls
cat inicio
cd misterio/
ls
grep "PISTA" *
grep "1.8" automoveis
grep "Altura: 1,8" automoveis
ls
grep "Annabel" pessoas
cd ruas
ls
cat Vila_Hart
clear
cd ..
ls
cd associacoes/
ls
grep "Annabel" *
cd ..
ls
grep "Annabel Church" *
grep "Annabel Church" ruas
grep "Annabel Church" pessoas
cd entrevistas/
ls
grep "Annabel Church" *
grep "Annabel" *
cd ..
ls
clear
ls
cd ..
ls
cat dica1
cat dica2
cat dica3
cat dica4
cat dica5
cd misterio/
ls
head -n 40 ruas/Vila_Hart | tail -n 1
head -n 179 ruas/Vila_Buckingham | tail -n 1
ls
cd entrevistas/
ls
cd entrevista-47246024
cat entrevista-47246024
cat entrevista-699607
cd ..
ls
head -n 5 automoveis
head -n 20 automoveis
grep "Placa L337" automoveis
grep "Placa L337" "Cor: Azul" "Marca: Honda"  automoveis
grep -e "L337" -e "Azul" auotmoveis
grep -e "L337" -e "Azul" automoveis
grep 'L337\|Azul\|Honda' automoveis
head automoveis
grep "\n" automoveis
grep "Annabel Church" automoveis
grep "Azul" automoveis | grep "Honda" automoveis
grep "Azul" automoveis && grep "Honda" automoveis
ls
grep "Church" automoveis
cd ..
ls
cat dica4
cat dica5
cat dica6
grep "Church" misterio/automoveis | head misterio/automoveis
head misterio/automoveis |  grep "Church" misterio/automoveis
head misterio/automoveis ||  grep "Church" misterio/automoveis
cat dica7
cd misterio/
grep -A 5 "L337" automoveis
grep -A 5 "L337\Honda" automoveis
grep -A 5 'L337\|Azul\|Honda' automoveis
grep -A 5 "L337" automoveis
cd ..
cat dica 7
cat dica7
cat dica8
cat dica9
ls
cd misterio/
ls
grep "Erika Owens" pessoas
grep "Joe Germuska" pessoas
grep "Emryus Arnane" pessoas
grep "Jacqui Maher" pessoas
cd entrevistas/
grep "Jacqui Maher" *
grep "Joe Germuska" *
cd ..
cd associacoes/
ls
clear
cd ..
grep 'Erika Hart|\Joe Germuska' pessoas
grep 'Erika Hart' pessoas
grep -A 5 "L337" automoveis
ls
cd ruas
ls
grep "Erika Owens" *
grep "Church" *
cd ..
ls
grep "Erika Owens" *
grep "Erika Owens" pessoas
grep "Joe Germuska" pessoas
grep "Emryus Arnane" pessoas
grep "Jacqui Maher" pessoas
cd entrevistas/
cd ..
cd ruas
head "Rua_Trapelo"
cd ..
cat dica3
cat dica4
cat dica5
head -n 173 ruas/Rua_Mattapan | tail -n 1
cd misterio/ruas
head -n 98 Rua_Trapelo | tail -n 1
head -n 275 Rua_Plainfield | tail -n 1
head -n 284 Travessa_Dunstable | tail -n 1
head -n 224 Travessa_Andover | tail -n 1
cd ..
cd entrevistas/
ls
cat entrevista-5455315
cat entrevista-29741223
cat entrevista-9620713
cat entrevista-904020
cd ..
ls
cd associacoes/
grep "Emryus Arnane" *
grep "Annabel Church" *
ls
echo "We got'em"
echo "Altos indicios de que Emryus Arnane e Annabel Church estão mancomunados"
cd ..
ls
cd ..
ls
sh mystery.sh
cat solucao
echo " " && sed -n '/Z/p' solucao | tail -n 6 | cut -c 8,22,23,41 && echo " "
echo "Agora sim: 'Ladies and gentlemen, we got'em"
echo "Emryus Arnane"
