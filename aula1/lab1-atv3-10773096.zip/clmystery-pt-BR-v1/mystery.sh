cat inicio
