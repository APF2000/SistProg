make groceries.txt
make fruits.txt
make vegetables.txt
make clean
make print
